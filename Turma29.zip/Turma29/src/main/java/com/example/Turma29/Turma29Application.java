package com.example.Turma29;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Turma29Application {

	public static void main(String[] args) {
		SpringApplication.run(Turma29Application.class, args);
	}

}
