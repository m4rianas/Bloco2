package com.example.Turma29;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Turma29ApplicationTests {

	@Test
	void contextLoads() {
	}

}
